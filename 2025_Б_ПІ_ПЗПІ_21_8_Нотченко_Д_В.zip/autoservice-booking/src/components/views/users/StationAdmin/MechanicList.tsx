import React, { useEffect, useState } from 'react';
import api from '../../../../utils/axiosInstance';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faCalendarAlt, faTrash, faEdit } from '@fortawesome/free-solid-svg-icons';
import { useNavigate } from 'react-router-dom';
import BackLink from "../../../ui/BackLink";

interface Mechanic {
    mechanic_id: number;
    name: string;
    specialization: string;
    experience_years: number;
}

interface ScheduleItem {
    schedule_id: number;
    date: string;
    start_time: string;
    end_time: string;
    availability_status: string;
}

const MechanicList: React.FC = () => {
    const [mechanics, setMechanics] = useState<Mechanic[]>([]);
    const [error, setError] = useState('');
    const [selectedMechanicId, setSelectedMechanicId] = useState<number | null>(null);
    const [schedule, setSchedule] = useState<ScheduleItem[]>([]);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchMechanics = async () => {
            try {
                const res = await api.get('/admin-sto/mechanics');
                setMechanics(res.data.mechanics || []);
            } catch (err) {
                setError('Failed to load mechanics');
            }
        };
        fetchMechanics();
    }, []);

    const fetchSchedule = async (mechanicId: number) => {
        try {
            const res = await api.get(`/admin-sto/mechanics/${mechanicId}/schedule`);
            setSchedule(res.data.schedule);
            setSelectedMechanicId(mechanicId);
        } catch (err) {
            setError('Failed to load schedule');
        }
    };

    const handleDeleteSchedule = async (scheduleId: number) => {
        if (!window.confirm('Are you sure you want to delete this schedule?')) return;
        try {
            await api.delete(`/admin-sto/mechanics/schedule/${scheduleId}`);
            setSchedule((prev) => prev.filter((s) => s.schedule_id !== scheduleId));
        } catch (err) {
            alert('Failed to delete schedule');
        }
    };

    const handleEditSchedule = (scheduleId: number) => {
        navigate(`/admin-sto/schedule/${scheduleId}/edit`);
    };

    return (
        <div className="container mt-4">
            <h3>Service Station Mechanics</h3>
            {error && <div className="alert alert-danger">{error}</div>}
            <ul className="list-group">
                {mechanics.map(mechanic => (
                    <li key={mechanic.mechanic_id} className="list-group-item d-flex justify-content-between align-items-center">
                        <div className="d-flex align-items-center">
                            <FontAwesomeIcon icon={faUser} className="fa-2x me-3" />
                            <div>
                                <strong>{mechanic.name}</strong><br />
                                <small>{mechanic.specialization} — {mechanic.experience_years} years</small>
                            </div>
                        </div>
                        <button className="btn btn-outline-primary btn-sm" onClick={() => fetchSchedule(mechanic.mechanic_id)}>
                            <FontAwesomeIcon icon={faCalendarAlt} className="me-1" /> View Schedule
                        </button>
                    </li>
                ))}
            </ul>
            {selectedMechanicId && (
                <div className="mt-4">
                    <h5>Schedule for Mechanic #{selectedMechanicId}</h5>
                    {schedule.length === 0 ? (
                        <p>No schedule available.</p>
                    ) : (
                        <ul className="list-group">
                            {schedule.map((s) => (
                                <li key={s.schedule_id} className="list-group-item d-flex justify-content-between align-items-center">
                                    <span>📅 {s.date} | 🕒 {s.start_time} - {s.end_time} | {s.availability_status}</span>
                                    <div>
                                        <button className="btn btn-sm btn-outline-secondary me-2" onClick={() => handleEditSchedule(s.schedule_id)}>
                                            <FontAwesomeIcon icon={faEdit} />
                                        </button>
                                        <button className="btn btn-sm btn-outline-danger" onClick={() => handleDeleteSchedule(s.schedule_id)}>
                                            <FontAwesomeIcon icon={faTrash} />
                                        </button>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            )}
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default MechanicList;
