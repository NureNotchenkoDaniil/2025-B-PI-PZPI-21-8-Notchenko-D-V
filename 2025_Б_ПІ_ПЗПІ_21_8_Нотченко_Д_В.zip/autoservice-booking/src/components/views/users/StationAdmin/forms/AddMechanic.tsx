import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../../../../utils/axiosInstance';
import BackLink from "../../../../ui/BackLink";

interface MechanicUser {
    user_id: number;
    email: string;
}

const AddMechanic: React.FC = () => {
    const navigate = useNavigate();

    const [form, setForm] = useState({
        user_id: '',
        specialization: '',
        experience_years: '',
    });

    const [mechanics, setMechanics] = useState<MechanicUser[]>([]);
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchMechanics = async () => {
            try {
                const res = await api.get('/admin-sto/mechanic-users');
                setMechanics(res.data.mechanics || []);
            } catch (err) {
                setError('Failed to load mechanic users');
            }
        };
        fetchMechanics();
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setMessage('');
        setError('');
        try {
            const res = await api.post('/admin-sto/mechanics', {
                user_id: parseInt(form.user_id),
                specialization: form.specialization,
                experience_years: parseInt(form.experience_years),
            });

            setMessage(res.data.message);
            setForm({ user_id: '', specialization: '', experience_years: '' });
            setTimeout(() => navigate('/admin-sto/station'), 2000);
        } catch (err: any) {
            setError(err.response?.data?.error || 'Failed to forms mechanic');
        }
    };

    return (
        <div className="container mt-4">
            <h3>Add Mechanic (Select by Email)</h3>
            {message && <div className="alert alert-success">{message}</div>}
            {error && <div className="alert alert-danger">{error}</div>}

            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label>Select Mechanic (by email)</label>
                    <select
                        name="user_id"
                        value={form.user_id}
                        onChange={handleChange}
                        className="form-control"
                        required
                    >
                        <option value="">-- Select Mechanic --</option>
                        {mechanics.map((m) => (
                            <option key={m.user_id} value={m.user_id}>
                                {m.email}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="mb-3">
                    <label>Specialization</label>
                    <input
                        type="text"
                        name="specialization"
                        value={form.specialization}
                        onChange={handleChange}
                        className="form-control"
                        required
                    />
                </div>

                <div className="mb-3">
                    <label>Experience (years)</label>
                    <input
                        type="number"
                        name="experience_years"
                        value={form.experience_years}
                        onChange={handleChange}
                        className="form-control"
                        required
                        min="0"
                        max="70"
                    />
                </div>

                <button type="submit" className="btn btn-success">Add Mechanic</button>
            </form>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default AddMechanic;

