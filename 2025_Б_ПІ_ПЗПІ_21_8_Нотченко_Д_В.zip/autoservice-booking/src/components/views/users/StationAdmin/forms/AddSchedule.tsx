import React, { useEffect, useState } from 'react';
import api from '../../../../../utils/axiosInstance';
import BackLink from "../../../../ui/BackLink";

interface Mechanic {
    mechanic_id: number;
    name: string;
}

const AddSchedule: React.FC = () => {
    const [mechanics, setMechanics] = useState<Mechanic[]>([]);
    const [form, setForm] = useState({
        mechanic_id: '',
        date: '',
        start_time: '',
        end_time: '',
        availability_status: 'available',
    });

    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchMechanics = async () => {
            try {
                const res = await api.get('/admin-sto/mechanics'); // Залежить від вашого бекенду
                setMechanics(res.data.mechanics || []);
            } catch (err) {
                setError('Failed to load mechanics');
            }
        };
        fetchMechanics();
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setMessage('');
        setError('');

        try {
            await api.post('/admin-sto/mechanics/schedule', {
                ...form,
                mechanic_id: parseInt(form.mechanic_id),
            });
            setMessage('Schedule successfully created!');
            setForm({
                mechanic_id: '',
                date: '',
                start_time: '',
                end_time: '',
                availability_status: 'available',
            });
        } catch (err: any) {
            setError(err.response?.data?.error || 'Failed to create schedule');
        }
    };

    return (
        <div className="container mt-4">
            <h3>Add Mechanic Schedule</h3>
            {message && <div className="alert alert-success">{message}</div>}
            {error && <div className="alert alert-danger">{error}</div>}

            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label>Mechanic</label>
                    <select
                        className="form-control"
                        name="mechanic_id"
                        value={form.mechanic_id}
                        onChange={handleChange}
                        required
                    >
                        <option value="">-- Select Mechanic --</option>
                        {mechanics.map(m => (
                            <option key={m.mechanic_id} value={m.mechanic_id}>
                                {m.name}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="mb-3">
                    <label>Date</label>
                    <input
                        type="date"
                        name="date"
                        value={form.date}
                        onChange={handleChange}
                        className="form-control"
                        required
                    />
                </div>

                <div className="mb-3">
                    <label>Start Time</label>
                    <input
                        type="time"
                        name="start_time"
                        value={form.start_time}
                        onChange={handleChange}
                        className="form-control"
                        required
                    />
                </div>

                <div className="mb-3">
                    <label>End Time</label>
                    <input
                        type="time"
                        name="end_time"
                        value={form.end_time}
                        onChange={handleChange}
                        className="form-control"
                        required
                    />
                </div>

                <div className="mb-3">
                    <label>Status</label>
                    <select
                        name="availability_status"
                        value={form.availability_status}
                        onChange={handleChange}
                        className="form-control"
                    >
                        <option value="available">Available</option>
                        <option value="unavailable">Unavailable</option>
                    </select>
                </div>

                <button type="submit" className="btn btn-primary">
                    Add Schedule
                </button>
            </form>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default AddSchedule;
