import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../../../../utils/axiosInstance';
import BackLink from "../../../../ui/BackLink";

interface OperatingHour {
    hour_id: number;
    day_of_week: string;
    opening_time: string;
    closing_time: string;
}

const OperatingHoursList: React.FC = () => {
    const [hours, setHours] = useState<OperatingHour[]>([]);
    const [formVisible, setFormVisible] = useState(false);
    const [form, setForm] = useState({
        day_of_week: '',
        opening_time: '',
        closing_time: '',
    });
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const fetchHours = async () => {
        try {
            const res = await api.get('/admin-sto/station/hours');
            setHours(res.data.hours || []);
        } catch {
            setError('Failed to load opening hours');
        }
    };

    useEffect(() => {
        fetchHours();
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setMessage('');
        setError('');

        try {
            const res = await api.post('/admin-sto/station/hours', form);
            setMessage(res.data.message);
            setForm({ day_of_week: '', opening_time: '', closing_time: '' });
            fetchHours(); // reload
            setFormVisible(false);
        } catch (err: any) {
            setError(err.response?.data?.error || 'Failed to forms operating hour');
        }
    };

    const handleDelete = async (id: number) => {
        if (!window.confirm('Are you sure you want to delete this entry?')) return;
        try {
            await api.delete(`/admin-sto/station/hours/${id}`);
            fetchHours();
        } catch {
            setError('Failed to delete entry');
        }
    };

    return (
        <div className="container mt-4">
            <h3>Opening Hours</h3>
            {message && <div className="alert alert-success">{message}</div>}
            {error && <div className="alert alert-danger">{error}</div>}
            <button className="btn btn-primary mb-3" onClick={() => setFormVisible(!formVisible)}>
                {formVisible ? 'Cancel' : 'Add Opening Hour'}
            </button>
            {formVisible && (
                <form onSubmit={handleSubmit} className="mb-4 border p-3 rounded shadow-sm">
                    <div className="mb-3">
                        <label>Day of Week</label>
                        <select
                            name="day_of_week"
                            className="form-control"
                            value={form.day_of_week}
                            onChange={handleChange}
                            required
                        >
                            <option value="">-- Select day --</option>
                            <option value="Monday">Monday</option>
                            <option value="Tuesday">Tuesday</option>
                            <option value="Wednesday">Wednesday</option>
                            <option value="Thursday">Thursday</option>
                            <option value="Friday">Friday</option>
                            <option value="Saturday">Saturday</option>
                            <option value="Sunday">Sunday</option>
                        </select>
                    </div>
                    <div className="mb-3">
                        <label>Opening Time</label>
                        <input
                            type="time"
                            name="opening_time"
                            className="form-control"
                            value={form.opening_time}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="mb-3">
                        <label>Closing Time</label>
                        <input
                            type="time"
                            name="closing_time"
                            className="form-control"
                            value={form.closing_time}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <button type="submit" className="btn btn-success">Save</button>
                </form>
            )}
            <table className="table table-bordered">
                <thead>
                <tr>
                    <th>Day</th>
                    <th>Open Time</th>
                    <th>Close Time</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                {hours.map((hour) => (
                    <tr key={hour.hour_id}>
                        <td>{hour.day_of_week}</td>
                        <td>{hour.opening_time}</td>
                        <td>{hour.closing_time}</td>
                        <td>
                            <button
                                className="btn btn-warning btn-sm me-2"
                                onClick={() => navigate(`/admin-sto/station/hours/${hour.hour_id}/edit`)}
                            >
                                Update
                            </button>
                            <button
                                className="btn btn-danger btn-sm"
                                onClick={() => handleDelete(hour.hour_id)}
                            >
                                Delete
                            </button>
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default OperatingHoursList;
