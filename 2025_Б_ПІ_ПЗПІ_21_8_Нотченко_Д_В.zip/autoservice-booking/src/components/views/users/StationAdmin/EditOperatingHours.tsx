import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../../../../utils/axiosInstance';
import BackLink from "../../../ui/BackLink";

const EditOperatingHour: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();

    const [form, setForm] = useState({
        opening_time: '',
        closing_time: '',
    });

    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchHour = async () => {
            try {
                const res = await api.get('/admin-sto/station/hours');
                const entry = res.data.hours.find((h: any) => h.hour_id.toString() === id);
                if (entry) {
                    setForm({
                        opening_time: entry.opening_time,
                        closing_time: entry.closing_time,
                    });
                } else {
                    setError('Operating hour not found');
                }
            } catch {
                setError('Failed to load data');
            }
        };

        fetchHour();
    }, [id]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setMessage('');
        try {
            await api.put(`/admin-sto/station/hours/${id}`, form);
            setMessage('Updated successfully');
            setTimeout(() => navigate('/admin-sto/station'), 1500);
        } catch (err: any) {
            setError(err.response?.data?.error || 'Update failed');
        }
    };

    return (
        <div className="container mt-4">
            <h3>Edit Operating Hour</h3>
            {message && <div className="alert alert-success">{message}</div>}
            {error && <div className="alert alert-danger">{error}</div>}

            <form onSubmit={handleSubmit} className="border p-4 rounded shadow-sm">
                <div className="mb-3">
                    <label>Opening Time</label>
                    <input
                        type="time"
                        className="form-control"
                        name="opening_time"
                        value={form.opening_time}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="mb-3">
                    <label>Closing Time</label>
                    <input
                        type="time"
                        className="form-control"
                        name="closing_time"
                        value={form.closing_time}
                        onChange={handleChange}
                        required
                    />
                </div>
                <button type="submit" className="btn btn-primary">Update</button>
            </form>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default EditOperatingHour;
