import React from 'react';
import { Link } from 'react-router-dom';
import BackLink from "../../../ui/BackLink";

const AdminSTOPanel: React.FC = () => {
    return (
        <div className="container mt-4">
            <h2>STO Administrator Panel</h2>
            <ul className="list-group">
                <li className="list-group-item">
                    <Link to="/admin-sto/station" className="text-decoration-none">View My Station</Link>
                </li>
                <li className="list-group-item">
                    <Link to="/admin-sto/mechanics/schedule/add" className="text-decoration-none">Add Mechanic Schedule</Link>
                </li>
                <li className="list-group-item">
                    <Link to="/admin-sto/services" className="text-decoration-none">Manage Services</Link>
                </li>
            </ul>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default AdminSTOPanel;
