import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../../../utils/axiosInstance';
import BackLink from "../../../ui/BackLink";

const EditMechanicSchedule: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();

    const [form, setForm] = useState({
        date: '',
        start_time: '',
        end_time: '',
        availability_status: 'available',
    });
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchSchedule = async () => {
            try {
                const res = await api.get(`/admin-sto/mechanics/schedule/${id}`);
                const scheduleItem = res.data.schedule;
                if (scheduleItem && scheduleItem.schedule_id.toString() === id) {
                    setForm({
                        date: scheduleItem.date,
                        start_time: scheduleItem.start_time,
                        end_time: scheduleItem.end_time,
                        availability_status: scheduleItem.availability_status,
                    });
                } else {
                    setError('Schedule not found');
                }
            } catch {
                setError('Failed to load schedule item');
            }
        };

        fetchSchedule();
    }, [id]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setMessage('');

        try {
            await api.put(`/admin-sto/mechanics/schedule/${id}`, form);
            setMessage('Schedule updated successfully');
            setTimeout(() => navigate('/admin-sto/station'), 2000);
        } catch (err: any) {
            setError(err.response?.data?.error || 'Failed to update schedule');
        }
    };

    return (
        <div className="container mt-4">
            <h3>Edit Mechanic Schedule</h3>
            {message && <div className="alert alert-success">{message}</div>}
            {error && <div className="alert alert-danger">{error}</div>}
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label>Date</label>
                    <input type="date" className="form-control" name="date" value={form.date} onChange={handleChange} required />
                </div>
                <div className="mb-3">
                    <label>Start Time</label>
                    <input type="time" className="form-control" name="start_time" value={form.start_time} onChange={handleChange} required />
                </div>
                <div className="mb-3">
                    <label>End Time</label>
                    <input type="time" className="form-control" name="end_time" value={form.end_time} onChange={handleChange} required />
                </div>
                <div className="mb-3">
                    <label>Status</label>
                    <select name="availability_status" className="form-control" value={form.availability_status} onChange={handleChange}>
                        <option value="available">Available</option>
                        <option value="busy">Busy</option>
                    </select>
                </div>
                <button type="submit" className="btn btn-primary">Update</button>
            </form>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default EditMechanicSchedule;
