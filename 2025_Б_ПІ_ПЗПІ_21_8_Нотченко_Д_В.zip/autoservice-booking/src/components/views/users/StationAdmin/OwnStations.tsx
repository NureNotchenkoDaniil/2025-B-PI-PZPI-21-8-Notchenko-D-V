import React, { useEffect, useState } from 'react';
import api from '../../../../utils/axiosInstance';
import { useNavigate } from 'react-router-dom';
import BackLink from "../../../ui/BackLink";

interface Station {
    station_id: number;
    name: string;
    address: string;
    contact_info: string;
    rating: number | null;
}

const OwnStations: React.FC = () => {
    const [stations, setStations] = useState<Station[]>([]);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchStations = async () => {
            try {
                const res = await api.get('/admin-sto/station');
                setStations(Array.isArray(res.data.stations) ? res.data.stations : [res.data.station]);
            } catch (err) {
                setError('Failed to load your stations.');
            }
        };
        fetchStations();
    }, []);

    return (
        <div className="container mt-4">
            <h2>My Service Stations</h2>
            {error && <div className="alert alert-danger">{error}</div>}
            <div className="row">
                {stations.map((station) => (
                    <div className="col-md-6 mb-4" key={station.station_id}>
                        <div className="card h-100 shadow">
                            <div className="card-body">
                                <h4 className="card-title">{station.name}</h4>
                                <p className="card-text"><strong>Address:</strong> {station.address}</p>
                                <p className="card-text"><strong>Contact:</strong> {station.contact_info}</p>
                                <p className="card-text"><strong>Rating:</strong> {station.rating ?? 'N/A'}</p>
                                <div className="d-flex flex-wrap gap-2 mt-3">
                                    <button
                                        className="btn btn-outline-primary flex-grow-1"
                                        onClick={() => navigate(`/admin-sto/station/${station.station_id}/hours`)}
                                    >
                                        View Opening Hours
                                    </button>
                                    <button
                                        className="btn btn-outline-secondary flex-grow-1"
                                        onClick={() => navigate(`/admin-sto/station/${station.station_id}/mechanics`)}
                                    >
                                        View Mechanics
                                    </button>
                                    <button
                                        className="btn btn-outline-success flex-grow-1"
                                        onClick={() => navigate(`/admin-sto/station/${station.station_id}/services`)}
                                    >
                                        View Services
                                    </button>
                                    <button
                                        className="btn btn-outline-success flex-grow-1"
                                        onClick={() => navigate(`/admin-sto/station/${station.station_id}/mechanics/add`)}
                                    >
                                        Add a Mechanic
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default OwnStations;
