import React, { useEffect, useState } from 'react';
import {Link} from "react-router-dom";
import api from '../../../../utils/axiosInstance';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faWrench, faTrash, faEdit, faPlus } from '@fortawesome/free-solid-svg-icons';
import BackLink from "../../../ui/BackLink";

interface Service {
    service_id: number;
    name: string;
    description: string;
    duration: string;
    cost: string;
}

const ServiceList: React.FC = () => {
    const [services, setServices] = useState<Service[]>([]);
    const [error, setError] = useState('');
    const [form, setForm] = useState<Omit<Service, 'service_id'>>({
        name: '',
        description: '',
        duration: '',
        cost: '',
    });
    const [editingId, setEditingId] = useState<number | null>(null);
    const [message, setMessage] = useState('');

    const fetchServices = async () => {
        try {
            const res = await api.get('/admin-sto/services');
            setServices(res.data.services || []);
        } catch {
            setError('Failed to load services');
        }
    };

    useEffect(() => {
        fetchServices();
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            if (editingId) {
                await api.post('/admin-sto/services', {
                    ...form,
                    price: form.cost ? parseFloat(form.cost) : null,
                    duration_minutes: form.duration ? parseInt(form.duration, 10) : null,
                });
                setMessage('Service updated');
            } else {
                await api.post('/admin-sto/services', form);
                setMessage('Service added');
            }
            setForm({ name: '', description: '', duration: '', cost: '' });
            setEditingId(null);
            fetchServices();
        } catch {
            setError('Failed to save service');
        }
    };

    const handleDelete = async (id: number) => {
        if (window.confirm('Are you sure you want to delete this service?')) {
            try {
                await api.delete(`/admin-sto/services/${id}`);
                setMessage('Service deleted');
                fetchServices();
            } catch {
                setError('Failed to delete service');
            }
        }
    };

    const handleEdit = (service: Service) => {
        setEditingId(service.service_id);
        setForm({
            name: service.name,
            description: service.description,
            duration: service.duration,
            cost: service.cost,
        });
    };

    return (
        <div className="container mt-4">
            <h3>Service Management</h3>
            {error && <div className="alert alert-danger">{error}</div>}
            {message && <div className="alert alert-success">{message}</div>}

            <form onSubmit={handleSubmit} className="mb-4 border p-3 bg-light" autoComplete="off">
                <h5>{editingId ? 'Edit Service' : 'Add New Service'}</h5>
                <div className="mb-2">
                    <input className="form-control" name="name" placeholder="Name" value={form.name} onChange={handleChange} required />
                </div>
                <div className="mb-2">
                    <textarea className="form-control" name="description" placeholder="Description" value={form.description} onChange={handleChange} required />
                </div>
                <div className="mb-2">
                    <input className="form-control" type="number" name="cost" placeholder="Cost of service" value={form.cost} onChange={handleChange} required />
                </div>
                <div className="mb-2">
                    <input className="form-control" type="number" name="duration" placeholder="Duration (minutes)" value={form.duration} onChange={handleChange} required />
                </div>
                <button type="submit" className="btn btn-success">
                    {editingId ? 'Update' : 'Add'} <FontAwesomeIcon icon={faPlus} className="ms-1" />
                </button>
            </form>

            <ul className="list-group">
                {services.map(service => (
                    <li key={service.service_id} className="list-group-item d-flex justify-content-between align-items-center">
                        <div className="d-flex align-items-center">
                            <FontAwesomeIcon icon={faWrench} className="fa-2x me-3 text-secondary" />
                            <div>
                                <strong>{service.name}</strong><br />
                                <small>{service.description}</small><br />
                                <small>Cost of the service: ${service.cost} | Duration: {service.duration} min</small>
                            </div>
                        </div>
                        <div>
                            <Link to={`/admin-sto/services/${service.service_id}/edit`} className="btn btn-sm btn-outline-primary me-2">
                                <FontAwesomeIcon icon={faEdit} />
                            </Link>
                            <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(service.service_id)}>
                                <FontAwesomeIcon icon={faTrash} />
                            </button>
                        </div>
                    </li>
                ))}
            </ul>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default ServiceList;
