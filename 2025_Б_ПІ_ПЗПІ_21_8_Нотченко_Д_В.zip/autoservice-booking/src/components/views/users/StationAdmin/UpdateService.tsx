import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../../../utils/axiosInstance';
import BackLink from "../../../ui/BackLink";

interface ServiceForm {
    name: string;
    description: string;
    cost: string;
    duration: string;
}

const UpdateService: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const [form, setForm] = useState<ServiceForm>({
        name: '',
        description: '',
        cost: '',
        duration: ''
    });
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchService = async () => {
            try {
                const res = await api.get(`/admin-sto/services`);
                const service = res.data.services.find((s: any) => s.service_id.toString() === id);
                if (service) {
                    setForm({
                        name: service.name,
                        description: service.description,
                        cost: service.cost.toString(),
                        duration: service.duration.toString(),
                    });
                } else {
                    setError('Service not found');
                }
            } catch {
                setError('Failed to fetch service');
            }
        };

        fetchService();
    }, [id]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setForm({ ...form, [name]: value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await api.put(`/admin-sto/services/${id}`, {
                name: form.name,
                description: form.description,
                cost: parseFloat(form.cost),
                duration: parseInt(form.duration, 10),
            });
            setMessage('Service updated successfully');
            setTimeout(() => navigate('/admin-sto/station'), 2000);
        } catch (err: any) {
            setError(err.response?.data?.error || 'Failed to update service');
        }
    };

    return (
        <div className="container mt-4">
            <h3>Update Service</h3>
            {message && <div className="alert alert-success">{message}</div>}
            {error && <div className="alert alert-danger">{error}</div>}
            <form onSubmit={handleSubmit} autoComplete="off">
                <div className="mb-3">
                    <label>Name</label>
                    <input name="name" value={form.name} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>Description</label>
                    <textarea name="description" value={form.description} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>Cost</label>
                    <input type="number" name="cost" value={form.cost} onChange={handleChange} className="form-control" min="0" />
                </div>
                <div className="mb-3">
                    <label>Duration (minutes)</label>
                    <input type="number" name="duration" value={form.duration} onChange={handleChange} className="form-control" min="0" />
                </div>
                <button type="submit" className="btn btn-primary">Update</button>
            </form>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default UpdateService;
