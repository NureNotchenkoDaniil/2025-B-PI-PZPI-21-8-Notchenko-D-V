import React, { useEffect, useState } from 'react';
import api from '../../../../utils/axiosInstance';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrash, faSliders } from '@fortawesome/free-solid-svg-icons';
import {useNavigate} from "react-router-dom";
import BackLink from "../../../ui/BackLink";

interface Car {
    car_id: number;
    make: string;
    model: string;
    year: number;
    license_plate: string;
    color: string;
    engine_type: string;
    transmission: string;
}

const Dashboard: React.FC = () => {
    const [cars, setCars] = useState<Car[]>([]);
    const navigate = useNavigate();
    const [form, setForm] = useState<Omit<Car, 'car_id'>>({
        make: '',
        model: '',
        year: new Date().getFullYear(),
        license_plate: '',
        color: '',
        engine_type: '',
        transmission: '',
    });
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    const fetchCars = async () => {
        try {
            const res = await api.get('/cars');
            setCars(res.data.cars || []);
        } catch (err) {
            setError('Failed to load your vehicles');
        }
    };

    const handleDelete = async (id: number) => {
        if (window.confirm('Are you sure you want to delete this car?')) {
            try {
                await api.delete(`/cars/${id}`);
                setMessage('Car deleted successfully');
                fetchCars();
            } catch {
                setError('Failed to delete car');
            }
        }
    };

    useEffect(() => {
        fetchCars();
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setMessage('');
        setError('');
        try {
            const res = await api.post('/cars', form);
            setMessage(res.data.message);
            setForm({
                make: '',
                model: '',
                year: new Date().getFullYear(),
                license_plate: '',
                color: '',
                engine_type: '',
                transmission: '',
            });
            fetchCars();
        } catch (err: any) {
            setError(err.response?.data?.message || 'Failed to add vehicle');
        }
    };

    return (
        <div className="container mt-4">
            <h3>My Vehicles</h3>
            {message && <div className="alert alert-success">{message}</div>}
            {error && <div className="alert alert-danger">{error}</div>}
            <ul className="list-group mb-4">
                {cars.map(car => (
                    <li key={car.car_id} className="list-group-item">
                        <strong>{car.make} {car.model}</strong> ({car.year}) — {car.license_plate} — {car.color}, {car.engine_type}, {car.transmission}
                        <div>
                            <button className="btn btn-sm btn-outline-primary me-2" onClick={() => navigate(`/cars/${car.car_id}/edit`)}>
                                <FontAwesomeIcon icon={faEdit} />
                            </button>
                            <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(car.car_id)}>
                                <FontAwesomeIcon icon={faTrash} />
                            </button>
                            <button
                                className="btn btn-outline-info btn-sm m-2"
                                onClick={() => navigate(`/cars/${car.car_id}/specifications`)}
                                title="View Specifications">
                                <FontAwesomeIcon icon={faSliders} />
                            </button>
                        </div>
                    </li>
                ))}
            </ul>

            <h4>Add New Car</h4>
            <form onSubmit={handleSubmit} className="mb-3 border p-3 bg-light">
                <div className="mb-2">
                    <input type="text" name="make" placeholder="Make" className="form-control" value={form.make} onChange={handleChange} required />
                </div>
                <div className="mb-2">
                    <input type="text" name="model" placeholder="Model" className="form-control" value={form.model} onChange={handleChange} required />
                </div>
                <div className="mb-2">
                    <input type="number" name="year" placeholder="Year" className="form-control" value={form.year} onChange={handleChange} required />
                </div>
                <div className="mb-2">
                    <input type="text" name="license_plate" placeholder="License Plate" className="form-control" value={form.license_plate} onChange={handleChange} required />
                </div>
                <div className="mb-2">
                    <input type="text" name="color" placeholder="Color" className="form-control" value={form.color} onChange={handleChange} required />
                </div>
                <div className="mb-2">
                    <input type="text" name="engine_type" placeholder="Engine Type" className="form-control" value={form.engine_type} onChange={handleChange} required />
                </div>
                <div className="mb-2">
                    <input type="text" name="transmission" placeholder="Transmission" className="form-control" value={form.transmission} onChange={handleChange} required />
                </div>
                <button type="submit" className="btn btn-primary">Add Car</button>
            </form>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default Dashboard;
