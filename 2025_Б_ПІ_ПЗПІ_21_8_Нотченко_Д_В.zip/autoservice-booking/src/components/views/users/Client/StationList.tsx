import React, { useEffect, useState } from 'react';
import api from '../../../../utils/axiosInstance';
import BackLink from "../../../ui/BackLink";

interface Station {
    station_id: number;
    name: string;
    address: string;
    contact_info: string;
    rating: number;
}

const ServiceStationList: React.FC = () => {
    const [stations, setStations] = useState<Station[]>([]);
    const [filters, setFilters] = useState({
        name: '',
        address: '',
        min_rating: '',
        max_rating: ''
    });
    const [error, setError] = useState('');

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFilters({ ...filters, [e.target.name]: e.target.value });
    };

    const fetchStations = async () => {
        try {
            const response = await api.get('/stations/search', { params: filters });
            setStations(response.data.stations || []);
            setError('');
        } catch (err: any) {
            setStations([]);
            setError(err.response?.data?.notice || 'Failed to fetch stations');
        }
    };

    useEffect(() => {
        fetchStations();
    }, []);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        fetchStations();
    };

    return (
        <div className="container mt-4">
            <h3>Find Service Stations</h3>

            <form onSubmit={handleSubmit} className="mb-4">
                <div className="row g-2">
                    <div className="col-md-3">
                        <input name="name" value={filters.name} onChange={handleChange} placeholder="Name" className="form-control" />
                    </div>
                    <div className="col-md-3">
                        <input name="address" value={filters.address} onChange={handleChange} placeholder="Address" className="form-control" />
                    </div>
                    <div className="col-md-2">
                        <input name="min_rating" value={filters.min_rating} onChange={handleChange} placeholder="Min Rating" type="number" min="0" max="5" className="form-control" />
                    </div>
                    <div className="col-md-2">
                        <input name="max_rating" value={filters.max_rating} onChange={handleChange} placeholder="Max Rating" type="number" min="0" max="5" className="form-control" />
                    </div>
                    <div className="col-md-2">
                        <button type="submit" className="btn btn-primary w-100">Search</button>
                    </div>
                </div>
            </form>

            {error && <div className="alert alert-warning">{error}</div>}

            <div className="row">
                {stations.map((station) => (
                    <div key={station.station_id} className="col-md-6 mb-4">
                        <div className="card shadow">
                            <div className="card-body">
                                <h5 className="card-title">{station.name}</h5>
                                <p className="card-text"><strong>Address:</strong> {station.address}</p>
                                <p className="card-text"><strong>Contact:</strong> {station.contact_info}</p>
                                <p className="card-text"><strong>Rating:</strong> {station.rating ?? 'N/A'}</p>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default ServiceStationList;

