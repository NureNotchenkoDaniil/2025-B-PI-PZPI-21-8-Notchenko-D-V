import React, { useEffect, useState } from 'react';
import api from '../../../../utils/axiosInstance';
import { useParams, useNavigate } from 'react-router-dom';
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faInfoCircle, faSliders, faTrash} from "@fortawesome/free-solid-svg-icons";
import {toast} from "react-toastify";
import BackLink from "../../../ui/BackLink";

const CarSpecificationView: React.FC = () => {
    const {carId} = useParams<{ carId: string }>();
    const [spec, setSpec] = useState<any>(null);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchSpec = async () => {
            try {
                const res = await api.get(`/cars/${carId}/specifications`);
                setSpec(res.data.specification);
            } catch {
                setError('Failed to load specification');
            }
        };
        fetchSpec();
    }, [carId]);

    if (error) return <div className="alert alert-danger mt-3">{error}</div>;

    return (
        <div className="container mt-4">
            <h3>Car Specifications</h3>
            {error && <div className="alert alert-danger">{error}</div>}

            {!spec ? (
                <div className="mt-3">
                    <p>No specification found.</p>
                    <button
                        className="btn btn-outline-info btn-sm m-2"
                        onClick={() => navigate(`/cars/${carId}/specifications/add`)}
                        title="Add Specification"
                    >
                        Add specification <FontAwesomeIcon icon={faSliders}/>
                    </button>
                </div>
            ) : (
                <>
                    <ul className="list-group">
                        <li className="list-group-item">Horsepower: {spec.horsepower} HP</li>
                        <li className="list-group-item">Torque: {spec.torque} Nm</li>
                        <li className="list-group-item">Fuel Capacity: {spec.fuel_capacity} L</li>
                        <li className="list-group-item">Mileage: {spec.mileage} km</li>
                        <li className="list-group-item">Weight: {spec.weight} kg</li>
                    </ul>
                    <button
                        className="btn btn-outline-danger btn-sm m-2"
                        onClick={async () => {
                            if (window.confirm("Are you sure you want to delete this specification?")) {
                                try {
                                    await api.delete(`/cars/${carId}/specifications`);
                                    toast.success("Specification deleted");
                                    navigate(`/cars/${carId}`);
                                } catch {
                                    toast.error("Failed to delete specification");
                                }
                            }
                        }}>
                        <FontAwesomeIcon icon={faTrash} className="me-1"/> Delete Specification
                    </button>
                    <button
                        className="btn btn-outline-info btn-sm"
                        onClick={() => navigate(`/cars/${carId}/specifications/edit`)}
                        title="Update specification">
                        <FontAwesomeIcon icon={faInfoCircle} className="me-1"/> Update specification
                    </button>
                </>
            )}
            <div>
                <BackLink label="Go back to previous page"/>
            </div>
        </div>
    )};

export default CarSpecificationView;
