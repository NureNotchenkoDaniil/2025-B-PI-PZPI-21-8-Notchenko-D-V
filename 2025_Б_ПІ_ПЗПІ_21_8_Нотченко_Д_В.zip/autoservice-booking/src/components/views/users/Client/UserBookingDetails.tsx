import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import api from '../../../../utils/axiosInstance';
import BackLink from "../../../ui/BackLink";

const UserBookingDetails: React.FC = () => {
    const {id} = useParams<{ id: string }>();
    const [booking, setBooking] = useState<any>(null);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchBooking = async () => {
            try {
                const res = await api.get(`/bookings/${id}`);
                setBooking(res.data);
            } catch {
                setError('Failed to load booking details.');
            }
        };
        fetchBooking();
    }, [id]);

    const handleDelete = async () => {
        if (!id) return;

        if (!window.confirm("Are you sure you want to cancel this booking?")) return;

        try {
            const res = await api.delete(`/bookings/${id}`);
            toast.success(res.data.message);
            navigate('/user/bookings');
        } catch (err: any) {
            toast.error(err.response?.data?.error || 'Failed to cancel booking');
        }
    };

    if (error) return <div className="alert alert-danger mt-3">{error}</div>;
    if (!booking) return <p className="mt-3">Loading booking details...</p>;

    return (
        <div className="container mt-4">
            <h3>Booking Details</h3>
            {error && <div className="alert alert-danger">{error}</div>}
            {!booking ? (
                <div>Loading...</div>
            ) : (
                <>
                    <ul className="list-group mb-3">
                        <li className="list-group-item">
                            <strong>Date/Time:</strong> {new Date(booking.date_time).toLocaleString()}</li>
                        <li className="list-group-item"><strong>Status:</strong> {booking.status}</li>
                        <li className="list-group-item">
                            <strong>Service:</strong> {booking.service.name} — {booking.service.description}</li>
                        <li className="list-group-item">
                            <strong>Car:</strong> {booking.car.make} {booking.car.model} ({booking.car.license_plate})
                        </li>
                        <li className="list-group-item"><strong>Station:</strong> {booking.station.name}</li>
                        <li className="list-group-item"><strong>Mechanic:</strong> {booking.mechanic.name}</li>
                    </ul>
                    {booking.status !== 'completed' && booking.status !== 'cancelled' && (
                        <button className="btn btn-outline-danger" onClick={handleDelete}>
                            Cancel Booking
                        </button>
                    )}
                </>
            )}
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
}

export default UserBookingDetails;
