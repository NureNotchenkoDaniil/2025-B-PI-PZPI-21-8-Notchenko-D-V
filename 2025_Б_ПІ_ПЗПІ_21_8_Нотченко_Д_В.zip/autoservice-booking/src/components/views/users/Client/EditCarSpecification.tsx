import React, {useEffect, useState} from 'react';
import api from '../../../../utils/axiosInstance';
import {useNavigate, useParams} from 'react-router-dom';
import {toast} from 'react-toastify';
import BackLink from "../../../ui/BackLink";

const EditCarSpecification: React.FC = () => {
    const {carId} = useParams<{ carId: string }>();
    const navigate = useNavigate();
    const [form, setForm] = useState({
        horsepower: '',
        torque: '',
        fuel_capacity: '',
        mileage: '',
        weight: '',
    });
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchSpec = async () => {
            try {
                const res = await api.get(`/cars/${carId}/specifications`);
                if (res.data.specification) {
                    const spec = res.data.specification;
                    setForm({
                        horsepower: spec.horsepower.toString(),
                        torque: spec.torque.toString(),
                        fuel_capacity: spec.fuel_capacity.toString(),
                        mileage: spec.mileage.toString(),
                        weight: spec.weight.toString(),
                    });
                }
            } catch {
                setError('Failed to fetch specification');
            }
        };
        fetchSpec();
    }, [carId]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setForm({...form, [e.target.name]: e.target.value});
    };

    const handleUpdate = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await api.put(`/cars/${carId}/specifications`, {
                ...form,
                horsepower: parseInt(form.horsepower),
                torque: parseInt(form.torque),
                fuel_capacity: parseFloat(form.fuel_capacity),
                mileage: parseFloat(form.mileage),
                weight: parseFloat(form.weight),
            });
            toast.success('Specification updated successfully');
            navigate(`/cars/${carId}/specifications`);
        } catch {
            toast.error('Failed to update specification');
        }
    };

    return (
        <div className="container mt-4">
            <h3>Edit Car Specification</h3>
            {error && <div className="alert alert-danger">{error}</div>}
            <form onSubmit={handleUpdate}>
                {['horsepower', 'torque', 'fuel_capacity', 'mileage', 'weight'].map(field => (
                    <div className="mb-3" key={field}>
                        <label className="form-label text-capitalize">{field.replace('_', ' ')}</label>
                        <input
                            type="number"
                            name={field}
                            className="form-control"
                            value={form[field as keyof typeof form]}
                            onChange={handleChange}
                            required
                            min="0"
                        />
                    </div>
                ))}
                <button type="submit" className="btn btn-primary">Update Specification</button>
            </form>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default EditCarSpecification;
