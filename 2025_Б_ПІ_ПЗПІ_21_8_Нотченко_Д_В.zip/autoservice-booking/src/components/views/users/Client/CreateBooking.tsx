import React, { useEffect, useState } from 'react';
import api from '../../../../utils/axiosInstance';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

interface Car {
    car_id: number;
    make: string;
    model: string;
    license_plate: string;
}

interface Service {
    service_id: number;
    name: string;
    description: string;
}

interface Station {
    station_id: number;
    name: string;
    address: string;
}

const CreateBooking: React.FC = () => {
    const navigate = useNavigate();

    const [cars, setCars] = useState<Car[]>([]);
    const [services, setServices] = useState<Service[]>([]);
    const [stations, setStations] = useState<Station[]>([]);
    const [form, setForm] = useState({
        car_id: '',
        service_id: '',
        station_id: '',
        date_time: '',
    });

    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const fetchInitialData = async () => {
            try {
                const stationRes = await api.get('/stations');
                const stationId = stationRes.data.stations[0]?.station_id;

                const [carRes, serviceRes] = await Promise.all([
                    api.get('/cars'),
                    api.get(`/stations/${stationId}/services`),
                ]);

                setCars(carRes.data.cars);
                setServices(serviceRes.data.services);
                setStations(stationRes.data.stations);
            } catch (err) {
                toast.error('Failed to load form data');
            }
        };

        fetchInitialData();
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        try {
            const res = await api.post('/bookings', {
                car_id: parseInt(form.car_id),
                service_id: parseInt(form.service_id),
                station_id: parseInt(form.station_id),
                date_time: form.date_time,
            });

            toast.success(res.data.message);
            //booking
            navigate('/user/bookings');
        } catch (err: any) {
            toast.error(err.response?.data?.error || 'Booking failed');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="container mt-4">
            <h3>Create New Booking</h3>
            <form onSubmit={handleSubmit} className="border p-4 rounded bg-light mt-3">
                <div className="mb-3">
                    <label>Car</label>
                    <select name="car_id" value={form.car_id} onChange={handleChange} className="form-control" required>
                        <option value="">-- Select your car --</option>
                        {cars.map(car => (
                            <option key={car.car_id} value={car.car_id}>
                                {car.make} {car.model} ({car.license_plate})
                            </option>
                        ))}
                    </select>
                </div>

                <div className="mb-3">
                    <label>Service</label>
                    <select name="service_id" value={form.service_id} onChange={handleChange} className="form-control" required>
                        <option value="">-- Select service --</option>
                        {services.map(service => (
                            <option key={service.service_id} value={service.service_id}>
                                {service.name}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="mb-3">
                    <label>Service Station</label>
                    <select name="station_id" value={form.station_id} onChange={handleChange} className="form-control" required>
                        <option value="">-- Select station --</option>
                        {stations.map(station => (
                            <option key={station.station_id} value={station.station_id}>
                                {station.name} ({station.address})
                            </option>
                        ))}
                    </select>
                </div>

                <div className="mb-3">
                    <label>Date and Time</label>
                    <input type="datetime-local" name="date_time" value={form.date_time} onChange={handleChange} className="form-control" required />
                </div>

                <button type="submit" className="btn btn-primary" disabled={loading}>
                    {loading ? 'Booking...' : 'Book Now'}
                </button>
            </form>
        </div>
    );
};

export default CreateBooking;
