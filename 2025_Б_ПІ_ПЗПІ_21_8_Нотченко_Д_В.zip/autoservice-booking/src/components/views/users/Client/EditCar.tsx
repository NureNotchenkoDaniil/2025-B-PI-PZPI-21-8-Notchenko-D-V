import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../../../utils/axiosInstance';
import BackLink from "../../../ui/BackLink";

const EditCar: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();

    const [form, setForm] = useState({
        make: '',
        model: '',
        year: '',
        license_plate: '',
        color: '',
        engine_type: '',
        transmission: ''
    });

    const [error, setError] = useState('');
    const [message, setMessage] = useState('');

    useEffect(() => {
        const fetchCar = async () => {
            try {
                const res = await api.get('/cars');
                const car = res.data.cars.find((c: any) => c.car_id.toString() === id);
                if (car) {
                    setForm({
                        make: car.make,
                        model: car.model,
                        year: car.year.toString(),
                        license_plate: car.license_plate,
                        color: car.color,
                        engine_type: car.engine_type,
                        transmission: car.transmission
                    });
                } else {
                    setError('Car not found');
                }
            } catch {
                setError('Failed to load car');
            }
        };

        fetchCar();
    }, [id]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await api.put(`/cars/${id}`, form);
            setMessage('Car updated successfully');
            setTimeout(() => navigate('/dashboard'), 1500);
        } catch {
            setError('Failed to update car');
        }
    };

    return (
        <div className="container mt-4">
            <h3>Edit Car</h3>
            {error && <div className="alert alert-danger">{error}</div>}
            {message && <div className="alert alert-success">{message}</div>}

            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label>Make</label>
                    <input type="text" name="make" value={form.make} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>Model</label>
                    <input type="text" name="model" value={form.model} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>Year</label>
                    <input type="number" name="year" value={form.year} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>License Plate</label>
                    <input type="text" name="license_plate" value={form.license_plate} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>Color</label>
                    <input type="text" name="color" value={form.color} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>Engine Type</label>
                    <input type="text" name="engine_type" value={form.engine_type} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>Transmission</label>
                    <input type="text" name="transmission" value={form.transmission} onChange={handleChange} className="form-control" required />
                </div>

                <button type="submit" className="btn btn-primary">Update Car</button>
            </form>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default EditCar;

