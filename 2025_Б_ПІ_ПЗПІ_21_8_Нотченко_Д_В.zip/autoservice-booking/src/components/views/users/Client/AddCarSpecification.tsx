import React, { useState } from 'react';
import api from '../../../../utils/axiosInstance';
import { useParams, useNavigate } from 'react-router-dom';
import BackLink from "../../../ui/BackLink";

const AddCarSpecification: React.FC = () => {
    const { carId } = useParams<{ carId: string }>();
    const navigate = useNavigate();
    const [form, setForm] = useState({
        horsepower: '',
        torque: '',
        fuel_capacity: '',
        mileage: '',
        weight: '',
    });
    const [error, setError] = useState('');
    const [message, setMessage] = useState('');

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await api.post(`/cars/${carId}/specifications`, {
                horsepower: parseInt(form.horsepower),
                torque: parseInt(form.torque),
                fuel_capacity: parseFloat(form.fuel_capacity),
                mileage: parseFloat(form.mileage),
                weight: parseFloat(form.weight),
            });
            setMessage('Specification saved successfully!');
            setTimeout(() => navigate(`/cars/${carId}/specifications`), 1500);
        } catch (err: any) {
            setError(err.response?.data?.error || 'Failed to save specification');
        }
    };

    return (
        <div className="container mt-4">
            <h3>Add Car Specifications</h3>
            {message && <div className="alert alert-success">{message}</div>}
            {error && <div className="alert alert-danger">{error}</div>}
            <form onSubmit={handleSubmit}>
                {['horsepower', 'torque', 'fuel_capacity', 'mileage', 'weight'].map((field) => (
                    <div className="mb-3" key={field}>
                        <label className="form-label text-capitalize">{field.replace('_', ' ')}</label>
                        <input
                            type="number"
                            className="form-control"
                            name={field}
                            value={(form as any)[field]}
                            onChange={handleChange}
                            required
                            min="0"
                        />
                    </div>
                ))}
                <button type="submit" className="btn btn-primary">Save</button>
            </form>
            <div>
                <BackLink label="Go back to previous page"/>
            </div>
        </div>
    );
};

export default AddCarSpecification;
