import React, { useEffect, useState } from 'react';
import api from '../../../../utils/axiosInstance';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye } from '@fortawesome/free-solid-svg-icons';
import BackLink from "../../../ui/BackLink";

interface Booking {
    booking_id: number;
    date_time: string;
    status: string;
    service: { name: string };
    station: { name: string };
}

const UserBookings: React.FC = () => {
    const [bookings, setBookings] = useState<Booking[]>([]);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchBookings = async () => {
            try {
                const res = await api.get('/bookings');
                setBookings(res.data);
            } catch (err) {
                setError('Failed to load bookings');
                toast.error('Failed to load bookings');
            }
        };
        fetchBookings();
    }, []);

    return (
        <div className="container mt-4">
            <h3>Your Bookings</h3>
            {error && <div className="alert alert-danger">{error}</div>}
            {bookings.length === 0 ? (
                <div className="alert alert-info mt-3">No bookings found.</div>
            ) : (
                <ul className="list-group">
                    {bookings.map(booking => (
                        <li key={booking.booking_id} className="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <strong>{new Date(booking.date_time).toLocaleString()}</strong><br />
                                <small>Service: {booking.service.name}</small><br />
                                <small>Station: {booking.station.name}</small><br />
                                <span className={`badge bg-${getBadgeColor(booking.status)} mt-1`}>
                                    {booking.status}
                                </span>
                            </div>
                            <button
                                className="btn btn-outline-primary btn-sm"
                                onClick={() => navigate(`/user/bookings/${booking.booking_id}`)}>
                                <FontAwesomeIcon icon={faEye} className="me-1" />
                                View
                            </button>
                        </li>
                    ))}
                </ul>
            )}
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

const getBadgeColor = (status: string) => {
    switch (status) {
        case 'pending': return 'warning';
        case 'in_progress': return 'info';
        case 'completed': return 'success';
        case 'cancelled': return 'danger';
        default: return 'secondary';
    }
};

export default UserBookings;
