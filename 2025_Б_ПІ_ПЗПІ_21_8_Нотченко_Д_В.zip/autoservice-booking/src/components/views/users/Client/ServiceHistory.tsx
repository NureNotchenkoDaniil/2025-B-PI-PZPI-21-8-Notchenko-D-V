import React, { useEffect, useState } from 'react';
import api from '../../../../utils/axiosInstance';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCar, faCalendarAlt, faWrench } from '@fortawesome/free-solid-svg-icons';
import BackLink from "../../../ui/BackLink";

interface HistoryItem {
    id: number;
    date: string;
    outcome: string | null;
    car: {
        make: string;
        model: string;
        license_plate: string;
    };
    service: {
        name: string;
        description: string;
    };
    station: {
        name: string;
        address: string;
    };
}

const ServiceHistory: React.FC = () => {
    const [history, setHistory] = useState<HistoryItem[]>([]);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchHistory = async () => {
            try {
                const res = await api.get('/cars/service-history');
                setHistory(res.data.history || []);
            } catch (err) {
                setError('Failed to load service history');
            }
        };

        fetchHistory();
    }, []);

    return (
        <div className="container mt-4">
            <h3>Your Service History</h3>
            {error && <div className="alert alert-danger">{error}</div>}
            {history.length === 0 ? (
                <p>No history found.</p>
            ) : (
                <ul className="list-group">
                    {history.map((item) => (
                        <li key={item.id} className="list-group-item">
                            <div><FontAwesomeIcon icon={faCalendarAlt} /> <strong>{new Date(item.date).toLocaleDateString()}</strong></div>
                            <div><FontAwesomeIcon icon={faCar} /> <strong>{item.car.make} {item.car.model}</strong> ({item.car.license_plate})</div>
                            <div><FontAwesomeIcon icon={faWrench} /> {item.service.name} — {item.service.description}</div>
                            <div><strong>Outcome:</strong> {item.outcome || 'Not specified'}</div>
                            <div><strong>Station:</strong> {item.station.name}, {item.station.address}</div>
                        </li>
                    ))}
                </ul>
            )}
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default ServiceHistory;
