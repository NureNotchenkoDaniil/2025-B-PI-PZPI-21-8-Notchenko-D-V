import React, { useState, useEffect } from 'react';
import api from '../../../../utils/axiosInstance';
import {useNavigate} from "react-router-dom";
import BackLink from "../../../ui/BackLink";

interface Station {
    station_id: number;
    name: string;
    address: string;
    contact_info: string;
    rating: number;
    user_id: number;
}

const AddServiceStation: React.FC = () => {
    const [form, setForm] = useState({
        name: '',
        address: '',
        contact_info: '',
        rating: '',
        user_id: '',
    });

    const [stations, setStations] = useState<Station[]>([]);
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            const response = await api.post('/admin/stations', {
                ...form,
                rating: form.rating ? parseFloat(form.rating) : null,
                user_id: parseInt(form.user_id),
            });
            setMessage(response.data.message);
            setError('');
            fetchStations();
        } catch (err: any) {
            setError(err.response?.data?.message || 'Failed to create station');
        }
    };

    const fetchStations = async () => {
        try {
            const res = await api.get('/admin/stations');
            setStations(res.data.stations || []);
        } catch (err) {
            setError('Failed to load stations');
        }
    };

    const handleDelete = async (id: number) => {
        if (!window.confirm('Are you sure you want to delete this station?')) return;
        try {
            await api.delete(`/admin/stations/${id}`);
            setMessage('Station deleted successfully');
            setError('');
            fetchStations();
        } catch (err) {
            setError('Failed to delete station');
        }
    };

    useEffect(() => {
        fetchStations();
    }, []);

    return (
        <div className="container mt-4">
            <h2>Add Service Station</h2>
            {message && <div className="alert alert-success">{message}</div>}
            {error && <div className="alert alert-danger">{error}</div>}

            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label>Name:</label>
                    <input name="name" value={form.name} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>Address:</label>
                    <input name="address" value={form.address} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>Contact Info:</label>
                    <input name="contact_info" value={form.contact_info} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>Rating (optional):</label>
                    <input type="number" step="0.1" name="rating" value={form.rating} onChange={handleChange} className="form-control" />
                </div>
                <div className="mb-3">
                    <label>User ID:</label>
                    <input type="number" name="user_id" value={form.user_id} onChange={handleChange} className="form-control" required />
                </div>
                <button type="submit" className="btn btn-primary">Add Station</button>
            </form>

            <h3 className="mt-5">All Service Stations</h3>
            <table className="table table-striped">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Contact Info</th>
                    <th>Rating</th>
                    <th>User ID</th>
                </tr>
                </thead>
                <tbody>
                {stations.map(st => (
                    <tr key={st.station_id}>
                        <td>{st.station_id}</td>
                        <td>{st.name}</td>
                        <td>{st.address}</td>
                        <td>{st.contact_info}</td>
                        <td>{st.rating ?? 'N/A'}</td>
                        <td>{st.user_id}</td>
                        <td>
                            <button
                                className="btn btn-danger btn-sm me-2"
                                onClick={() => handleDelete(st.station_id)}
                            >
                                Delete
                            </button>
                            <button
                                className="btn btn-secondary btn-sm"
                                onClick={() => navigate(`/admin/stations/${st.station_id}/edit`)}
                            >
                                Update
                            </button>
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default AddServiceStation;
