import React, { useEffect, useState } from 'react';
import api from '../../../../utils/axiosInstance';
import BackLink from "../../../ui/BackLink";

interface User {
    user_id: number;
    name: string;
    email: string;
    role: string;
}

const UserList: React.FC = () => {
    const [users, setUsers] = useState<User[]>([]);
    const [error, setError] = useState('');
    const currentUser = JSON.parse(localStorage.getItem('user') || '{}');

    const fetchUsers = async () => {
        try {
            const response = await api.get('/admin/dashboard');
            setUsers(response.data.users);
        } catch (err) {
            setError('Failed to load users');
        }
    };

    const updateRole = async (userId: number, role: string) => {
        if (userId === currentUser.user_id) {
            alert("You can't change your own role.");
            return;
        }

        try {
            const response = await api.patch(`/admin/users/${userId}/role`, { role });
            alert(response.data.message);
            fetchUsers();
        } catch (err: any) {
            alert(err.response?.data?.error || 'Failed to update role');
        }
    };

    useEffect(() => {
        fetchUsers();
    }, []);

    return (
        <div className="container mt-4">
            <h3>Users</h3>
            {error && <p className="text-danger">{error}</p>}
            <table className="table table-bordered">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Change Role</th>
                </tr>
                </thead>
                <tbody>
                {users.map(user => (
                    <tr key={user.user_id}>
                        <td>{user.name}</td>
                        <td>{user.email}</td>
                        <td>{user.role}</td>
                        <td>
                            <select
                                value={user.role}
                                onChange={e => updateRole(user.user_id, e.target.value)}
                                disabled={user.user_id === currentUser.user_id}
                            >
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                                <option value="admin_sto">Admin STO</option>
                                <option value="mechanic">Mechanic</option>
                            </select>
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default UserList;
