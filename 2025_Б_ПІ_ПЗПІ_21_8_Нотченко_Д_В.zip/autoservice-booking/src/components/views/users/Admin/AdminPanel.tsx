import React from 'react';
import { Link } from 'react-router-dom';
import BackLink from "../../../ui/BackLink";

const AdminPanel: React.FC = () => {
    return (
        <div className="container mt-4">
            <h2 className="mb-3">Admin Panel</h2>
            <p>Welcome to the admin dashboard. Choose an action below:</p>

            <ul className="list-group mb-4">
                <li className="list-group-item">
                    <Link to="/admin/user-list" className="text-decoration-none">View All Users</Link>
                </li>
                <li className="list-group-item">
                    <Link to="/admin/stations/create" className="text-decoration-none">Create Service Station</Link>
                </li>
                <li className="list-group-item">
                    <Link to="/" className="text-decoration-none">Go Back to Home</Link>
                </li>
            </ul>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default AdminPanel;

