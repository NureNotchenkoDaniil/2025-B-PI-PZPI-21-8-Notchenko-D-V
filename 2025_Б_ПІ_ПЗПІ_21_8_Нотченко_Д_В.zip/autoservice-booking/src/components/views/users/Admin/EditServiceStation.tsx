import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../../../utils/axiosInstance';
import BackLink from "../../../ui/BackLink";

interface UserOption {
    user_id: number;
    email: string;
}

interface StationForm {
    name: string;
    address: string;
    contact_info: string;
    rating: string;
    user_id: string;
    email: string;
}

const EditServiceStation: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const [users, setUsers] = useState<UserOption[]>([]);

    const [form, setForm] = useState<StationForm>({
        name: '',
        address: '',
        contact_info: '',
        rating: '',
        user_id: '',
        email: '',
    });

    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchStationAndUsers = async () => {
            try {
                const usersRes = await api.get('/admin/dashboard');
                setUsers(usersRes.data.users);

                const stationsRes = await api.get('/admin/stations');
                const station = stationsRes.data.stations.find((s: any) => s.station_id.toString() === id);

                if (station) {
                    setForm({
                        name: station.name,
                        address: station.address,
                        contact_info: station.contact_info,
                        rating: station.rating?.toString() ?? '',
                        user_id: station.user_id.toString(),
                        email: station.email?.toString() ?? '',
                    });
                } else {
                    setError('Station not found');
                }
            } catch (err) {
                setError('Failed to fetch station or users');
            }
        };

        fetchStationAndUsers();
    }, [id]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            const response = await api.put(`/admin/stations/${id}`, {
                ...form,
                rating: form.rating ? parseFloat(form.rating) : null,
                user_id: parseInt(form.user_id)
            });
            setMessage(response.data.message);
            setError('');
        } catch (err: any) {
            setError(err.response?.data?.message || 'Update failed');
        }
    };

    return (
        <div className="container mt-4">
            <h2>Update Service Station</h2>
            {message && <div className="alert alert-success">{message}</div>}
            {error && <div className="alert alert-danger">{error}</div>}

            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label>Name:</label>
                    <input name="name" value={form.name} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>Address:</label>
                    <input name="address" value={form.address} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>Contact Info:</label>
                    <input name="contact_info" value={form.contact_info} onChange={handleChange} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label>Rating:</label>
                    <input name="rating" value={form.rating} onChange={handleChange} type="number" step="0.1" className="form-control" />
                </div>
                <div className="mb-3">
                    <label>User ID:</label>
                    <select
                        name="user_id"
                        value={form.user_id}
                        onChange={(e) => setForm({ ...form, user_id: e.target.value })}
                        className="form-control"
                        required>
                        <option value="">-- Select User --</option>
                        {users.map((user) => (
                            <option key={user.user_id} value={user.user_id}>
                                {user.email}
                            </option>
                        ))}
                    </select>
                </div>
                <button type="submit" className="btn btn-primary">Update Station</button>
            </form>
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default EditServiceStation;
