import React, { useEffect, useState } from 'react';
import api from '../../../../utils/axiosInstance';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faInfoCircle, faCalendarCheck } from '@fortawesome/free-solid-svg-icons';
import { toast } from 'react-toastify';
import {useNavigate} from "react-router-dom";
import BackLink from "../../../ui/BackLink";

interface Booking {
    booking_id: number;
    date_time: string;
    status: string;
    service: {
        name: string;
    };
}

const getStatusBadgeClass = (status: string) => {
    switch (status) {
        case 'pending':
            return 'bg-secondary';
        case 'in_progress':
            return 'bg-warning text-dark';
        case 'completed':
            return 'bg-success';
        case 'cancelled':
            return 'bg-danger';
        default:
            return 'bg-secondary';
    }
};

const MechanicBookings: React.FC = () => {
    const [bookings, setBookings] = useState<Booking[]>([]);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchBookings = async () => {
            try {
                const res = await api.get('/mechanic/bookings');
                setBookings(res.data.bookings || []);
            } catch (err: any) {
                setError(err.response?.data?.error || 'Failed to load bookings');
            }
        };

        fetchBookings();
    }, []);

    const handleStatusUpdate = async (bookingId: number, newStatus: string) => {
        try {
            await api.patch(`/mechanic/bookings/${bookingId}/status`, {status: newStatus});
            toast.success(`Status updated to ${newStatus.replace('_', ' ')}`);
            setBookings((prev) =>
                prev.map((b) =>
                    b.booking_id === bookingId ? {...b, status: newStatus} : b
                )
            );
        } catch (err: any) {
            alert(err.response?.data?.error || 'Failed to update status');
        }
    };

    return (
        <div className="container mt-4">
            <h3>My Bookings</h3>
            {error && <div className="alert alert-danger">{error}</div>}
            {bookings.length === 0 ? (
                <p>No bookings found.</p>
            ) : (
                <ul className="list-group">
                    {bookings.map((booking) => (
                        <li
                            key={booking.booking_id}
                            className="list-group-item d-flex justify-content-between align-items-center"
                        >
                            <div>
                                <FontAwesomeIcon icon={faCalendarCheck} className="me-2 text-primary"/>
                                <strong>{new Date(booking.date_time).toLocaleString()}</strong>
                                <div>
                                    Service: <em>{booking.service.name}</em>
                                </div>
                                <div>
                                    Status:{' '}
                                    <span className={`badge ${getStatusBadgeClass(booking.status)}`}>
                  {booking.status.replace('_', ' ')}
                </span>
                                </div>
                                <div className="mt-2 d-flex">
                                    <select
                                        className="form-select form-select-sm me-2"
                                        value={booking.status}
                                        onChange={(e) => handleStatusUpdate(booking.booking_id, e.target.value)}
                                    >
                                        <option value="pending">Pending</option>
                                        <option value="in_progress">In Progress</option>
                                        <option value="completed">Completed</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>
                                </div>
                            </div>
                            <button
                                className="btn btn-outline-info btn-sm"
                                onClick={() => navigate(`/mechanic/bookings/${booking.booking_id}`)}
                                title="View booking details">
                                <FontAwesomeIcon icon={faInfoCircle} className="me-1"/> View Details
                            </button>
                        </li>
                    ))}
                </ul>
            )}
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
}

export default MechanicBookings;
