import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../../../../utils/axiosInstance';
import BackLink from "../../../ui/BackLink";

interface Booking {
    booking_id: number;
    date_time: string;
    status: string;
    service: {
        name: string;
        description: string;
    };
    car: {
        make: string;
        model: string;
        license_plate: string;
    };
    user: {
        name: string;
        email: string;
    };
}

const BookingDetails: React.FC = () => {
    const { bookingId } = useParams<{ bookingId: string }>();
    const [booking, setBooking] = useState<Booking | null>(null);
    const [outcome, setOutcome] = useState('');
    const [success, setSuccess] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchDetails = async () => {
            try {
                const res = await api.get(`/mechanic/bookings/${bookingId}`);
                setBooking(res.data.booking);
            } catch (err: any) {
                setError(err.response?.data?.error || 'Failed to load booking details');
            }
        };
        fetchDetails();
    }, [bookingId]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSuccess('');
        setError('');
        try {
            const res = await api.post('/mechanic/service-history', {
                booking_id: booking?.booking_id,
                outcome: outcome || null,
            });
            setSuccess(res.data.message);
            setOutcome('');
        } catch (err: any) {
            setError(err.response?.data?.error || 'Failed to save service history');
        }
    };

    if (error) return <div className="alert alert-danger mt-3">{error}</div>;
    if (!booking) return <div className="mt-3">Loading...</div>;

    return (
        <div className="container mt-4">
            <h3>Booking Details</h3>
            <ul className="list-group mb-4">
                <li className="list-group-item"><strong>Date/Time:</strong> {new Date(booking.date_time).toLocaleString()}</li>
                <li className="list-group-item"><strong>Status:</strong> {booking.status}</li>
                <li className="list-group-item"><strong>Service:</strong> {booking.service.name} — {booking.service.description}</li>
                <li className="list-group-item"><strong>Car:</strong> {booking.car.make} {booking.car.model} ({booking.car.license_plate})</li>
                <li className="list-group-item"><strong>Customer:</strong> {booking.user.name} ({booking.user.email})</li>
            </ul>

            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label htmlFor="outcome" className="form-label">Service Outcome (optional)</label>
                    <textarea
                        id="outcome"
                        name="outcome"
                        className="form-control"
                        value={outcome}
                        onChange={(e) => setOutcome(e.target.value)}
                        maxLength={255}
                        rows={3}
                    />
                </div>
                <button type="submit" className="btn btn-success">Save Service History</button>
            </form>
            {success && <div className="alert alert-success mt-3">{success}</div>}
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default BookingDetails;
