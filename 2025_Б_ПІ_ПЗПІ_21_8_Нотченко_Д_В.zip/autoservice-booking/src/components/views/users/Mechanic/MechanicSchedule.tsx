import React, { useEffect, useState } from 'react';
import api from '../../../../utils/axiosInstance';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faClock } from '@fortawesome/free-solid-svg-icons';
import BackLink from "../../../ui/BackLink";

interface Schedule {
    schedule_id: number;
    date: string;
    start_time: string;
    end_time: string;
    availability_status: string;
}

const MechanicSchedule: React.FC = () => {
    const [schedules, setSchedules] = useState<Schedule[]>([]);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchSchedule = async () => {
            try {
                const res = await api.get('/mechanic/schedule');
                setSchedules(res.data.schedules || []);
            } catch (err) {
                setError('Failed to load mechanic schedule');
            }
        };

        fetchSchedule();
    }, []);

    return (
        <div className="container mt-4">
            <h3>My Work Schedule</h3>
            {error && <div className="alert alert-danger">{error}</div>}

            {schedules.length === 0 ? (
                <p>No schedule available.</p>
            ) : (
                <ul className="list-group">
                    {schedules.map((s) => (
                        <li key={s.schedule_id} className="list-group-item d-flex align-items-center">
                            <FontAwesomeIcon icon={faClock} className="me-3 text-primary" />
                            <div>
                                <strong>{new Date(s.date).toLocaleDateString()}</strong><br />
                                Time: {s.start_time} - {s.end_time}<br />
                                Status: <span className={`badge bg-${s.availability_status === 'available' ? 'success' : 'secondary'}`}>
                  {s.availability_status}
                </span>
                            </div>
                        </li>
                    ))}
                </ul>
            )}
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default MechanicSchedule;
