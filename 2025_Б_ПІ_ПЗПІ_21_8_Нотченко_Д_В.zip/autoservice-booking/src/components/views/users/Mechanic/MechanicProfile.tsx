import React, { useEffect, useState } from 'react';
import api from '../../../../utils/axiosInstance';
import {useNavigate} from "react-router-dom";
import BackLink from "../../../ui/BackLink";

interface Mechanic {
    name: string;
    specialization: string;
    experience_years: number;
}

interface Station {
    station_id: number;
    name: string;
    address: string;
    contact_info: string | null;
    rating: number | null;
}

const MechanicProfile: React.FC = () => {
    const [mechanic, setMechanic] = useState<Mechanic | null>(null);
    const [station, setStation] = useState<Station | null>(null);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const res = await api.get('/mechanic/profile');
                setMechanic(res.data.mechanic);
                setStation(res.data.station);
            } catch (err: any) {
                setError(err.response?.data?.error || 'Failed to load profile');
            }
        };

        fetchProfile();
    }, []);

    const handleViewBookings = () => {
        navigate('/mechanic/bookings');
    }

    return (
        <div className="container mt-4">
            <h2>Mechanic Profile</h2>

            {error && <div className="alert alert-danger">{error}</div>}

            {mechanic && station && (
                <div className="card shadow p-4">
                    <h4 className="mb-3">Mechanic Info</h4>
                    <ul className="list-group mb-4">
                        <li className="list-group-item"><strong>Name:</strong> {mechanic.name}</li>
                        <li className="list-group-item"><strong>Specialization:</strong> {mechanic.specialization}</li>
                        <li className="list-group-item"><strong>Experience:</strong> {mechanic.experience_years} years</li>
                    </ul>

                    <h4 className="mb-3">Service Station Info</h4>
                    <ul className="list-group">
                        <li className="list-group-item"><strong>Name:</strong> {station.name}</li>
                        <li className="list-group-item"><strong>Address:</strong> {station.address}</li>
                        <li className="list-group-item"><strong>Contact:</strong> {station.contact_info ?? 'N/A'}</li>
                        <li className="list-group-item"><strong>Rating:</strong> {station.rating ?? 'N/A'}</li>
                    </ul>
                    <div className="d-grid mt-4">
                        <button className="btn btn-primary btn-lg" onClick={handleViewBookings}>
                            View My Bookings
                        </button>
                        <button
                            className="btn btn-outline-primary btn-lg mt-3"
                            onClick={() => navigate('/mechanic/schedule')}>
                            View My Schedule
                        </button>
                    </div>
                </div>
            )}
            <div>
                <BackLink label="Go back to previous page" />
            </div>
        </div>
    );
};

export default MechanicProfile;
