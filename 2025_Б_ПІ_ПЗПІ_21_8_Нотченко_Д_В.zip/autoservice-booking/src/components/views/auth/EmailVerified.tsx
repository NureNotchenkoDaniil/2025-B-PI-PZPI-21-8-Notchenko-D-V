import React from 'react';
import { Link } from 'react-router-dom';

const EmailVerified: React.FC = () => {
    return (
        <div style={{ padding: '2rem', textAlign: 'center' }}>
            <h1>✅ Email successfully verified</h1>
            <p>You can now access all features of your account.</p>
            <p style={{ fontWeight: 'bold' }}>
                Now you can <Link to="/login">Log In</Link>
            </p>
        </div>
    );
};

export default EmailVerified;
