import api from "../../../../utils/axiosInstance";

export const refreshToken = async () => {
    try {
        const token = localStorage.getItem('token');
        const response = await api.post('/refresh', null, {
            headers: { Authorization: `Bearer ${token}` },
        });

        localStorage.setItem('token', response.data.token);
        return response.data.token;
    } catch (error) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        throw new Error('Session expired. Please log in again.');
    }
};
