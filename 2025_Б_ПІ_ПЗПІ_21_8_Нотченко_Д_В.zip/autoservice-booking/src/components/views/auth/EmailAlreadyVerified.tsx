import React from 'react';

const EmailAlreadyVerified: React.FC = () => {
    return (
        <div style={{ padding: '2rem', textAlign: 'center' }}>
            <h1>📩 Email already verified</h1>
            <p>No further action is needed.</p>
        </div>
    );
};

export default EmailAlreadyVerified;
