import React, { useState } from 'react';
import api from "../../../utils/axiosInstance";
import { useNavigate } from 'react-router-dom';

interface RegisterFormData {
    name: string;
    email: string;
    password: string;
    password_confirmation: string;
}

interface ValidationErrors {
    [key: string]: string[];
}

const Register: React.FC = () => {
    const [formData, setFormData] = useState<RegisterFormData>({
        name: '',
        email: '',
        password: '',
        password_confirmation: '',
    });

    const [errors, setErrors] = useState<ValidationErrors>({});
    const navigate = useNavigate();

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            const response = await api.post('/register', formData, {
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            localStorage.setItem('token', response.data.token);
            navigate('/');
        } catch (error: any) {
            if (error.response && error.response.status === 422) {
                setErrors(error.response.data);
            } else {
                alert('Registration failed. Please try again.');
            }
        }
    };

    return (
        <div className="container mt-5" style={{ maxWidth: '500px' }}>
            <h2 className="mb-4">Register</h2>
            <form onSubmit={handleSubmit}>
                <div className="form-group mb-3">
                    <label htmlFor="name">Name:</label>
                    <input
                        type="text"
                        name="name"
                        className="form-control"
                        value={formData.name}
                        onChange={handleChange}
                    />
                    {errors.name && <small className="text-danger">{errors.name[0]}</small>}
                </div>

                <div className="form-group mb-3">
                    <label htmlFor="email">Email:</label>
                    <input
                        type="email"
                        name="email"
                        className="form-control"
                        value={formData.email}
                        onChange={handleChange}
                    />
                    {errors.email && <small className="text-danger">{errors.email[0]}</small>}
                </div>

                <div className="form-group mb-3">
                    <label htmlFor="password">Password:</label>
                    <input
                        type="password"
                        name="password"
                        className="form-control"
                        value={formData.password}
                        onChange={handleChange}
                    />
                    {errors.password && <small className="text-danger">{errors.password[0]}</small>}
                </div>

                <div className="form-group mb-4">
                    <label htmlFor="password_confirmation">Confirm Password:</label>
                    <input
                        type="password"
                        name="password_confirmation"
                        className="form-control"
                        value={formData.password_confirmation}
                        onChange={handleChange}
                    />
                </div>

                <button type="submit" className="btn btn-primary w-100">
                    Register
                </button>
            </form>
        </div>
    );
};

export default Register;
