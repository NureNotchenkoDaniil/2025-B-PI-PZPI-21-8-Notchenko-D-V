import React, { useState } from 'react';
import api from "../../../utils/axiosInstance";

const Login: React.FC = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setErrors] = useState<string | null>(null);

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setErrors(null);

        try {
            const res = await api.post('/login', { email, password });
            const { token, user } = res.data;

            localStorage.setItem('token', token);
            localStorage.setItem('user', JSON.stringify(user));
            window.location.href = '/';

        } catch (err: any) {
            if (err.response && err.response.data) {
                setErrors(err.response.data.error || 'Login failed');
            } else {
                setErrors('Something went wrong');
            }
        }
    };

    return (
        <div className="container mt-5" style={{ maxWidth: 450 }}>
            <h2 className="mb-4 text-center">Login</h2>

            {errors && (
                <div className="alert alert-danger" role="alert">
                    {errors}
                </div>
            )}

            <form onSubmit={handleLogin} noValidate>
                <div className="mb-3">
                    <label htmlFor="email" className="form-label">Email address</label>
                    <input
                        type="email"
                        className="form-control"
                        id="email"
                        value={email}
                        required
                        onChange={(e) => setEmail(e.target.value)}
                    />
                    {!email && <div className="invalid-feedback d-block">Email is required.</div>}
                </div>

                <div className="mb-3">
                    <label htmlFor="password" className="form-label">Password</label>
                    <input
                        type="password"
                        className="form-control"
                        id="password"
                        value={password}
                        required
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    {!password && <div className="invalid-feedback d-block">Password is required.</div>}
                </div>
                <button type="submit" className="btn btn-primary w-100">
                    Login
                </button>
            </form>
        </div>
    );
};

export default Login;
