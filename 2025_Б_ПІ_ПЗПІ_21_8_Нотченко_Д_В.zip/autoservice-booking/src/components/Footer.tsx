import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/axiosInstance';
import './styles/Footer.css';

interface Station {
    station_id: number;
    name: string;
    address: string;
}

const Footer: React.FC = () => {
    const [stations, setStations] = useState<Station[]>([]);

    useEffect(() => {
        const fetchPopularStations = async () => {
            try {
                const res = await api.get('/stations/popular');
                setStations(res.data.stations);
            } catch (err) {
                console.error('Failed to load popular stations');
            }
        };
        fetchPopularStations();
    }, []);

    return (
        <footer className="footer-wrapper mt-5">
            <div className="container py-4">
                <div className="row text-light">
                    <div className="col-md-4 mb-3">
                        <h5>Contact Us</h5>
                        <p>Email: support@autoservice.com</p>
                        <p>Phone: +38 (050) 123-45-67</p>
                        <p>Address: Avtoservisna St., 10, Kyiv</p>
                    </div>
                    <div className="col-md-4 mb-3">
                        <h5>Top Rated Stations</h5>
                        <ul className="list-unstyled">
                            {stations.map((station) => (
                                <li key={station.station_id}>
                                    <Link to={`/stations/${station.station_id}`} className="footer-link">
                                        {station.name} — {station.address}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </div>
                    <div className="col-md-4 mb-3">
                        <h5>About Project</h5>
                        <p>
                            Autoservice Booking is a modern platform for convenient online service station
                            search, booking management, and car service control.
                        </p>
                    </div>
                </div>
                <div className="text-center mt-4 border-top pt-3 text-light small">
                    &copy; {new Date().getFullYear()} Autoservice Booking. All rights reserved.
                </div>
            </div>
        </footer>
    );
};

export default Footer;
