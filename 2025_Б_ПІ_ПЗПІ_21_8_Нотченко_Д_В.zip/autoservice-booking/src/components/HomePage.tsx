import React, { useEffect } from 'react';
import { Container, Row, Col, Card, Accordion } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faCalendarCheck,
    faSearchLocation,
    faTachometerAlt,
    faCar,
    faWrench,
    faClipboardList,
    faBell,
    faFilter,
    faLayerGroup,
    faBolt
} from '@fortawesome/free-solid-svg-icons';
import AOS from 'aos';
import 'aos/dist/aos.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles/HomePage.css';

const Homepage: React.FC = () => {
    const navigate = useNavigate();

    useEffect(() => {
        AOS.init({ duration: 1000 });
    }, []);

    return (
        <Container className="mt-4">
            {/* Intro */}
            <Row className="align-items-center mb-5" data-aos="fade-up">
                <Col md={6}>
                    <h1 className="display-5 fw-bold text-primary">CarCareBooking</h1>
                    <p className="lead">
                        Modern solution for booking car service appointments. Stop calling — start clicking.
                    </p>
                    <Link to="/stations" className="btn btn-primary">
                        <FontAwesomeIcon icon={faSearchLocation} className="me-2" />
                        Find Service Station
                    </Link>
                </Col>
                <Col md={6}>
                    <img
                        src={`${process.env.PUBLIC_URL}/assets/img/intro.png`}
                        alt="Garage"
                        className="img-fluid rounded shadow"
                    />
                </Col>
            </Row>

            {/* Core Features */}
            <Row className="text-center mb-5">
                <h2 className="mb-4" data-aos="fade-right">Core Features</h2>
                {[
                    {
                        title: 'Online Booking',
                        text: 'Book services without calls. Select date, service, and car in a few clicks.',
                        img: 'booking.png',
                        icon: faCalendarCheck
                    },
                    {
                        title: 'Service History',
                        text: 'Access full vehicle service records at any time.',
                        img: 'oilChange.png',
                        icon: faClipboardList
                    },
                    {
                        title: 'Smart Scheduling',
                        text: 'Automatic mechanic assignment based on availability.',
                        img: 'undercarriage.png',
                        icon: faWrench
                    },
                ].map((feature, i) => (
                    <Col md={4} key={i} data-aos="zoom-in">
                        <Card className="mb-4 shadow-sm h-100">
                            <Card.Img
                                variant="top"
                                src={`/assets/img/${feature.img}`}
                                alt={feature.title}
                                style={{ maxHeight: '180px', objectFit: 'cover' }}
                            />
                            <Card.Body>
                                <Card.Title className="text-primary">
                                    <FontAwesomeIcon icon={feature.icon} className="me-2" />
                                    {feature.title}
                                </Card.Title>
                                <Card.Text>{feature.text}</Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                ))}
            </Row>

            {/* Quick Access */}
            <Row className="mb-5">
                <h2 className="mb-3" data-aos="fade-right">Quick Access</h2>
                <Col md={4} data-aos="fade-up">
                    <Card className="h-100 text-center shadow-sm">
                        <Card.Body>
                            <Card.Title>
                                <FontAwesomeIcon icon={faTachometerAlt} className="me-2 text-secondary" />
                                My Dashboard
                            </Card.Title>
                            <Card.Text>Check your cars, bookings and service history.</Card.Text>
                            <Link to="/dashboard" className="btn btn-outline-primary">Go to Dashboard</Link>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4} data-aos="fade-up">
                    <Card className="h-100 text-center shadow-sm">
                        <Card.Body>
                            <Card.Title>
                                <FontAwesomeIcon icon={faSearchLocation} className="me-2 text-secondary" />
                                Find a Station
                            </Card.Title>
                            <Card.Text>Browse service stations near you and book online.</Card.Text>
                            <Link to="/stations" className="btn btn-outline-primary">Browse Stations</Link>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4} data-aos="fade-up">
                    <Card className="h-100 text-center shadow-sm">
                        <Card.Body>
                            <Card.Title>
                                <FontAwesomeIcon icon={faCar} className="me-2 text-secondary" />
                                My Bookings
                            </Card.Title>
                            <Card.Text>Manage or cancel your current bookings.</Card.Text>
                            <Link to="/user/bookings" className="btn btn-outline-primary">View Bookings</Link>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            {/* Advantages with Accordion */}
            <Row className="bg-light p-4 rounded mb-4" data-aos="fade-left">
                <Col>
                    <h3 className="text-dark mb-3">Why CarCareBooking?</h3>
                    <Accordion flush>
                        <Accordion.Item eventKey="0">
                            <Accordion.Header><FontAwesomeIcon icon={faBolt} className="me-2 text-warning" /> Avoid scheduling conflicts</Accordion.Header>
                            <Accordion.Body>
                                Smart logic prevents double bookings and helps avoid mechanic overlaps.
                            </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="1">
                            <Accordion.Header><FontAwesomeIcon icon={faBell} className="me-2 text-info" /> Instant email confirmations</Accordion.Header>
                            <Accordion.Body>
                                You receive an instant email notification when your booking is confirmed.
                            </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="2">
                            <Accordion.Header><FontAwesomeIcon icon={faLayerGroup} className="me-2 text-success" /> Browse services easily</Accordion.Header>
                            <Accordion.Body>
                                All services come with descriptions, prices and durations — no surprises.
                            </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="3">
                            <Accordion.Header><FontAwesomeIcon icon={faFilter} className="me-2 text-secondary" /> Filter stations</Accordion.Header>
                            <Accordion.Body>
                                Filter stations by location, rating, and price range to find the perfect fit.
                            </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="4">
                            <Accordion.Header><FontAwesomeIcon icon={faClipboardList} className="me-2 text-danger" /> Integrated service history</Accordion.Header>
                            <Accordion.Body>
                                Your service data is stored securely and is accessible at any time.
                            </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="5">
                            <Accordion.Header><FontAwesomeIcon icon={faCar} className="me-2 text-primary" /> Modern, intuitive interface</Accordion.Header>
                            <Accordion.Body>
                                Simple and clean design across admin, mechanic, and user roles.
                            </Accordion.Body>
                        </Accordion.Item>
                    </Accordion>
                </Col>
            </Row>
        </Container>
    );
};

export default Homepage;
