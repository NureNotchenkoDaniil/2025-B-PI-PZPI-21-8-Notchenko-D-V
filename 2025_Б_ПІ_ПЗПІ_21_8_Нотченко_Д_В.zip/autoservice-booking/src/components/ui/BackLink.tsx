import React from 'react';
import { useNavigate } from 'react-router-dom';
import {faArrowLeft} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";

const BackLink: React.FC<{ label?: string }> = ({ label = 'Back' }) => {
    const navigate = useNavigate();

    return (
        <a
            role="button"
            className="text-decoration-none text-primary mb-3 mt-3 d-inline-block"
            onClick={() => navigate(-1)}
            style={{ cursor: 'pointer' }}>
            <FontAwesomeIcon icon={faArrowLeft} className="me-2"/>
             {label}
        </a>
    );
};

export default BackLink;
