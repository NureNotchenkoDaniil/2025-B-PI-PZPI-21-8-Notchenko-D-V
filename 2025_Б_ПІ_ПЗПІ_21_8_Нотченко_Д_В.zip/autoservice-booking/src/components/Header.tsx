import React, {useEffect, useState} from 'react';
import {Link, useNavigate} from 'react-router-dom';
import './styles/Header.css';
import api from "../utils/axiosInstance";
import {refreshToken} from "./views/auth/utils/RefreshToken";
import {faPhone, faEnvelope} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";

const Header: React.FC = () => {
  const [user, setUser] = useState<{ name: string; role: string } | null>(null);
  const [sessionExpired, setSessionExpired] = useState(false);
  const [isSticky, setIsSticky] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => {
      setIsSticky(window.scrollY > 80);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const storedUser = localStorage.getItem('user');

    if (token && storedUser) {
      api
          .get('/me')
          .then((res) => {
            if (res.data && res.data.user) {
              console.log("User loaded", res.data);
              setUser(JSON.parse(storedUser));
            } else {
              handleLogout();
              //setSessionExpired(true);
            }
          })
          .catch((err) => {
            if (err.response?.status === 401) {
              setSessionExpired(true);
            } else {
              handleLogout();
            }
          });
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    setSessionExpired(false);
    navigate('/login');
  };

  const handleRefresh = async () => {
    try {
      const newToken = await refreshToken();
      localStorage.setItem('token', newToken);
      setSessionExpired(false);

      const storedUser = localStorage.getItem('user');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
    } catch (error) {
      console.error('Token refresh failed:', error);
      handleLogout();
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  return (
      <div className={`header-wrapper ${isSticky ? 'sticky' : ''}`}>
        <div className="top-contact">
          <span><FontAwesomeIcon icon={faPhone}/> +380 (00) 123-45-67 | <FontAwesomeIcon icon={faEnvelope} />️ info@autoservice-booking.com</span>
        </div>
      <header className="header">
        <Link to="/" className="logo">
          AutoService Booking
        </Link>
        <nav className="nav">
          {user ? (
              <>
            <span className="greeting">
              {getGreeting()}, {user.name}
            </span>
                {user.role === 'admin' && (
                    <Link to="/admin" className="link">
                      Admin Panel
                    </Link>
                )}
                {user?.role === 'admin_sto' && (
                    <Link to="/admin-sto" className="link">My Service Stations</Link>
                )}
                {user?.role === 'mechanic' && (
                    <Link to="/mechanic/profile" className="link">My working profile</Link>
                )}
                {sessionExpired ? (
                    <button className="btn btn-warning btn-sm" onClick={handleRefresh}>
                      Expand session
                    </button>
                ) : (
                    <button className="btn btn-outline-light btn-sm" onClick={handleLogout}>
                      Logout
                    </button>
                )}
              </>
          ) : (
              <>
                <Link to="/login" className="link">
                  Login
                </Link>
                <Link to="/register" className="link">
                  Register
                </Link>
              </>
          )}
        </nav>
      </header>
    </div>
  );
};

export default Header;

