import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import {ToastContainer} from "react-toastify";
import Header from './components/Header';
import Register from './components/views/auth/Register';
import Login from "./components/views/auth/Login";
import AdminPanel from "./components/views/users/Admin/AdminPanel";
import EmailVerified from "./components/views/auth/EmailVerified";
import EmailAlreadyVerified from "./components/views/auth/EmailAlreadyVerified";
import UserList from "./components/views/users/Admin/UserList";
import AddServiceStation from "./components/views/users/Admin/AddServiceStation";
import EditServiceStation from "./components/views/users/Admin/EditServiceStation";
import AdminSTOPanel from "./components/views/users/StationAdmin/AdminPanel";
import OwnStations from "./components/views/users/StationAdmin/OwnStations";
import MechanicList from "./components/views/users/StationAdmin/MechanicList";
import AddMechanic from "./components/views/users/StationAdmin/forms/AddMechanic";
import OpeningHoursList from "./components/views/users/StationAdmin/forms/OperatingHoursList";
import EditOperatingHour from "./components/views/users/StationAdmin/EditOperatingHours";
import AddSchedule from "./components/views/users/StationAdmin/forms/AddSchedule";
import ServiceList from "./components/views/users/StationAdmin/ServiceList";
import UpdateService from "./components/views/users/StationAdmin/UpdateService";
import MechanicProfile from "./components/views/users/Mechanic/MechanicProfile";
import MechanicBookings from "./components/views/users/Mechanic/MechanicBookings";
import BookingDetails from "./components/views/users/Mechanic/BookingDetails";
import MechanicSchedule from "./components/views/users/Mechanic/MechanicSchedule";
import EditMechanicSchedule from "./components/views/users/StationAdmin/EditMechanicSchedule";
import Dashboard from "./components/views/users/Client/Dashboard";
import EditCar from "./components/views/users/Client/EditCar";
import CarSpecificationsView from "./components/views/users/Client/CarSpecificationsView";
import AddCarSpecification from "./components/views/users/Client/AddCarSpecification";
import EditCarSpecification from "./components/views/users/Client/EditCarSpecification";
import ServiceHistory from "./components/views/users/Client/ServiceHistory";
import StationList from "./components/views/users/Client/StationList";
import CreateBooking from "./components/views/users/Client/CreateBooking";
import UserBookings from "./components/views/users/Client/UserBookings";
import UserBookingDetails from "./components/views/users/Client/UserBookingDetails";
import Footer from "./components/Footer";
import HomePage from "./components/HomePage";


const App: React.FC = () => {
    const user = JSON.parse(localStorage.getItem('user') || 'null');

    return (
        <Router>
            <Header/>
              <ToastContainer/>
            <div style={{padding: '24px'}}>
                <Routes>
                    <Route path="/login" element={<Login/>}/>
                    <Route path="/register" element={<Register/>}/>
                    <Route path="/register/email-verified" element={<EmailVerified/>}/>
                    <Route path="/email-already-verified" element={<EmailAlreadyVerified/>}/>
                    <Route path="/" element={<HomePage />} />
                    {user && user.role === "admin" && (
                        <>
                            <Route path="/admin" element={<AdminPanel/>}/>
                            <Route path="/admin/user-list" element={<UserList/>}/>
                            <Route path="/admin/stations/create" element={<AddServiceStation/>}/>
                            <Route path="/admin/stations/:id/edit" element={<EditServiceStation />} />
                        </>
                    )}
                    {user && user.role === 'admin_sto' && (
                        <>
                            <Route path="/admin-sto" element={<AdminSTOPanel/>}/>
                            <Route path="/admin-sto/station" element={<OwnStations/>}/>
                            <Route path="/admin-sto/station/:id/mechanics" element={<MechanicList/>}/>
                            <Route path="/admin-sto/station/:id/mechanics/add" element={<AddMechanic/>}/>
                            <Route path="/admin-sto/mechanics/schedule/add" element={<AddSchedule />} />
                            <Route path="/admin-sto/station/:station_id/hours" element={<OpeningHoursList/>} />
                            <Route path="/admin-sto/station/hours/:id/edit" element={<EditOperatingHour />} />
                            <Route path="/admin-sto/station/:stationId/services" element={<ServiceList />} />
                            <Route path="/admin-sto/services/:id/edit" element={<UpdateService />} />
                            <Route path="/admin-sto/schedule/:id/edit" element={<EditMechanicSchedule />} />
                        </>
                    )}
                    {user && user.role === 'mechanic' && (
                        <>
                            <Route path="/mechanic/profile" element={<MechanicProfile/>} />
                            <Route path="/mechanic/bookings" element={<MechanicBookings/>} />
                            <Route path="/mechanic/bookings/:bookingId" element={<BookingDetails />} />
                            <Route path="/mechanic/schedule" element={<MechanicSchedule />} />
                        </>
                    )}
                    {user && user.role === 'user' && (
                        <>
                            <Route path="/dashboard" element={<Dashboard/>}/>
                            <Route path="/cars/:id/edit" element={<EditCar/>}/>
                            <Route path="/cars/:carId/specifications" element={<CarSpecificationsView />} />
                            <Route path="/cars/:carId/specifications/add" element={<AddCarSpecification />} />
                            <Route path="/cars/:carId/specifications/edit" element={<EditCarSpecification />} />
                            <Route path="/cars/service-history" element={<ServiceHistory/>} />
                            <Route path="/stations" element={<StationList />} />
                            <Route path="/bookings" element={<CreateBooking />} />
                            <Route path="/user/bookings" element={<UserBookings/>} />
                            <Route path="/user/bookings/:id" element={<UserBookingDetails />} />
                        </>
                    )}
                </Routes>
            </div>
            <Footer/>
        </Router>
    );
};

export default App;


